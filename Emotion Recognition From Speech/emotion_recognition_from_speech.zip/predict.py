import librosa
import numpy as np
import joblib
import sys

def extract_features(file_path):
    y, sr = librosa.load(file_path, duration=3, offset=0.5)
    mfcc = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40).T, axis=0)
    chroma = np.mean(librosa.feature.chroma_stft(y=y, sr=sr).T, axis=0)
    mel = np.mean(librosa.feature.melspectrogram(y=y, sr=sr).T, axis=0)
    return np.concatenate((mfcc, chroma, mel)).reshape(1, -1)

def predict(file_path):
    model = joblib.load("model.pkl")
    features = extract_features(file_path)
    prediction = model.predict(features)
    print("Predicted Emotion:", prediction[0])

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python predict.py path/to/audio.wav")
    else:
        predict(sys.argv[1])