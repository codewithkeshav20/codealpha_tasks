import os
import librosa
import numpy as np
import pandas as pd

def extract_features(file_path):
    y, sr = librosa.load(file_path, duration=3, offset=0.5)
    mfcc = np.mean(librosa.feature.mfcc(y=y, sr=sr, n_mfcc=40).T, axis=0)
    chroma = np.mean(librosa.feature.chroma_stft(y=y, sr=sr).T, axis=0)
    mel = np.mean(librosa.feature.melspectrogram(y=y, sr=sr).T, axis=0)
    return np.concatenate((mfcc, chroma, mel))

def load_data(directory):
    features = []
    for file in os.listdir(directory):
        if file.endswith(".wav"):
            label = file.split("-")[2]  # Assumes emotion label is the 3rd component (e.g., RAVDESS)
            feature = extract_features(os.path.join(directory, file))
            features.append([*feature, label])
    return pd.DataFrame(features)

if __name__ == "__main__":
    df = load_data("data/")
    df.to_csv("features.csv", index=False)
    print("Features extracted and saved to features.csv")